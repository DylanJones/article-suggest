
thefile = sys.argv[1]
str=open(thefile,"r").read()
print(str)
